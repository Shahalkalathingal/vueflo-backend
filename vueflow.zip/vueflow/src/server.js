const mongoose = require('mongoose');
const express = require('express');

var logger = require('morgan');
var authRouter = require('./routes/auth');
var liveRouter = require('./routes/live');
var otherRouter = require('./routes/other');
const User = require('./schema/User')
const Live = require('./schema/Lives')

const server_ip = `108.175.11.224`

require('dotenv').config();

const app = express();
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

const http = require('http').createServer(app);
const io = require('socket.io')(http);
const NodeMediaServer = require('node-media-server');
const config = {
  rtmp: {
    port: 1935,
    chunk_size: 60000,
    gop_cache: true,
    ping: 30,
    ping_timeout: 60
  },
  http: {
    port: 8000,
    mediaroot: './media',
    allow_origin: '*'
  },

  trans: {
    ffmpeg: '/usr/local/bin/ffmpeg',
    tasks: [
      {
        app: 'live', // or other
        hls: true,
        hlsFlags: '[hls_time=2:hls_list_size=3:hls_flags=delete_segments]',
        dash: true,
        dashFlags: '[f=dash:window_size=3:extra_window_size=5]',
        'websocket-flv': true,

      },
    ]
  }
};

const config_example = {
  rtmp: {
    port: 1935,
    chunk_size: 600000,
    gop_cache: true,
    ping: 60,
    ping_timeout: 30
  },
  http: {
    port: 8000,
    allow_origin: '*'
  },
  trans: {
    ffmpeg: '/usr/local/bin/ffmpeg',
    tasks: [
      {
        app: 'live',
        ac: 'aac',
        hls: true,

        hlsFlags: '[hls_time=1:hls_list_size=3:hls_flags=delete_segments]',

        dash: true,
        dashFlags: ['-f', 'dash', '-window_size', '3', '-extra_window_size', '5']
      }
    ]
  },
}


const nms = new NodeMediaServer(config);





nms.on('postPublish', (id, streamPath, args) => {
  let session = nms.getSession(id)
  const userId = streamPath.split('/')[2]
  console.log(userId, streamPath.split('/'))
  console.log(userId)
  try {
    if (!mongoose.isValidObjectId(userId)) {

      return
    }
    User.findOne({ _id: userId }).then((res) => {
      if (!res || !res._id) {
        return
      }

      Live.create({
        live: id,
        user: userId,
        url: {
          flv: `http://${server_ip}:8000/${session.appname}/${res._id}.flv`,
          rtmp: `rtmp://${server_ip}:1935/${session.appname}/${res._id}`,
          hls: `http://${server_ip}:8000/${session.appname}/${res._id}/index.m3u8`,
          dash: `http://${server_ip}:8000/${session.appname}/${res._id}/index.mpd`,
          ws_flv: `ws://${server_ip}:8000/${session.appname}/${res._id}.flv`
        }
      })
    })
  } catch (error) {

  }

  io.emit('newStream', streamPath);
});




nms.on('donePublish', (id, streamPath, args) => {
  const userId = streamPath.split('/')[2]

  try {
    if (!mongoose.isValidObjectId(userId)) {

      return
    }
    User.findOne({ _id: userId }).then((res) => {

      if (!res || !res._id) {

        return
      }
      Live.findOneAndDelete({
        live: id
      }).then((res) => {
        return
      })
    })
  } catch (error) {
  }
})
nms.run();

http.listen(process.env.EXPRESS_PORT || 3000, async () => {
  console.log('Server running on http://localhost:3000');

  const mongoUri = process.env.MONGO_URI || 'mongodb://localhost/vueflo';
  await mongoose.connect(mongoUri, {
    keepAlive: true
  }).then(() => console.log('Connected To MongoDB')).catch(err => console.log(err));
});

io.on('connection', (socket) => {
  console.log('A user connected');


  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });
});


// app.get('/', (req, res) => {
//   res.send('VueFlow Server');
// });
app.use('/auth', authRouter);
app.use('/lives', liveRouter);
app.use('/', otherRouter);


module.exports = app;

// mongoose.connect('mongodb://localhost/vueflo');
// var db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function callback() {
//   console.log("Database Connected : mongodb");
// });




// // error handler
// app.use(function (err, req, res, next) {
//   // set locals, only providing error in development
//   res.locals.message = err.message;
//   res.locals.error = req.app.get('env') === 'development' ? err : {};

//   // render the error page
//   res.status(err.status || 500);
//   res.render('error');
// });
